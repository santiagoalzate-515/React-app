import React, { useEffect } from "react";
import { TodoItem } from "../TodoItem";
import { TodoContext } from "../TodoContext";
import { TodoItemBorrados } from "./TodoItemBorrados";


function TodosBorrados() {

  const { todoBorrado,todoDelatePapelera,todoAgainPapelera } = React.useContext(TodoContext);

  
  
  return (
    
     
      <div>
         <h1>Tareas Borradas</h1>
        {todoBorrado.map((todo) => (
          <TodoItemBorrados
            key={todo.Text}
            text={todo.Text}
            delate={()=>todoDelatePapelera(todo.Text)}
            again={()=>todoAgainPapelera(todo.Text)}

          />
        ))}
      </div>
   
  );
}

export {TodosBorrados}

