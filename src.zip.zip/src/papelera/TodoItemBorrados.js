import React from "react";
import "../TodoItem/TodoItem.css"
import { DelateIcon } from "../TodoItem/DelateIcon";
import { AgainTodo } from "./AgainTodo";





function TodoItemBorrados({text,delate,again}) {
    return(
        <div>
            <div className="container-tarea-checked">
            <p className="text">{text}</p>
            <DelateIcon
            delate={delate}
            />

            <AgainTodo
            again={again}
            />
            
        </div>
        </div>
        
    )
}

export{TodoItemBorrados};