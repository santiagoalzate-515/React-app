import React from "react";
import {ReactComponent as CheckSVG} from "../TodoItem/check.svg";

function AgainTodo({again}) {
    return(
        <span className="Icon-checked-tamaño"
        onClick={again}
        >
            <CheckSVG fill="gray"/>
        </span>
    )
}

export{AgainTodo}

