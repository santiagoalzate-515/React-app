import logo from '../platzi.webp';
import './App.css';
import { TodoCounter } from '../TodoCounter'
import { TodoSearch } from '../TodoSearch';
import {TodoItem} from '../TodoItem';
import { CreateTodoButton } from '../CreateTodoButton';
import React, { useContext, useState } from 'react';
import { Todocontainer } from '../TodoItem/Todocontainer';
import { useLocalStorage } from '../TodoContext/useLocalStorage';
import { TodosLoading } from '../TodosLoading';
import { EmptyTodos } from '../EmptyTodos';
import { TodosError } from '../TodosError';
import { TodoProvider } from '../TodoContext';
import { TodoContext } from '../TodoContext';
import { Modal } from '../Modal';
import { TodoForm } from '../TodoForm';
import { TodoList } from '../TodoItem/TodoList';
import { TodoButtonPapelera } from '../papelera/TodoButtonPapelera';
import { Modal2 } from '../papelera/Modal2';
import { TodosBorrados } from '../papelera/TodosBorrados';
import { PapeleraTodoMap } from '../papelera/TodosBorrados';
import { Root } from '../Root';
import { Initial } from '../initial/Initial';
import { Todocontainer1 } from '../container/TodoContainer1';



function App() {
  
  return (
    <TodoProvider>
      <TodoContext.Consumer>
        {({searchValue,
            setSearchValue,
            Todos,
            saveTodo,
            error,
            loading,
            todoChecked,
            todoDelate,
            searchTodos,
            todoTotal,
            todoCompleted,
            openModal,
            setOpenModal,
            todopapelera,
            settodopapelera,
            todoBorrado,
            todoDelatePaelera,
            todoDelatePapelera,
            todoAgainPapelera
            
        })=>(<React.Fragment>

                            <TodoCounter
                                todocompleted={todoCompleted}
                                todototal={todoTotal}
                            />



          <Todocontainer1>
          <TodoSearch
          searchValue={searchValue}
          setSearchValue={setSearchValue}
          />
    
    
          <Todocontainer>
            {error && <TodosError/>}
            {loading && <TodosLoading/>}
            {(!loading && !error && searchTodos.length==0)&& <EmptyTodos/>}
    
            {searchTodos.map(
              (todo)=><TodoItem
                key={todo.Text}
                text={todo.Text}
                completed
                
                
                
                
                ={todo.Commpleted}
                checked={()=>todoChecked(todo.Text)}
                delate={()=>todoDelate(todo.Text)}
    
              />
            )}


          </Todocontainer>

          <CreateTodoButton/>

          <TodoButtonPapelera/>
           
         
          </Todocontainer1>
    
         

          {openModal && <Modal><TodoForm/></Modal>}
          {todopapelera && <Modal2><TodosBorrados/></Modal2>}
        </React.Fragment>)}
      </TodoContext.Consumer>
    </TodoProvider>
  )
}
  

        
export default App;