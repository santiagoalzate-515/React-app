import React from "react";
import { Modal2 } from '../papelera/Modal2';
import { Modal } from '../Modal';
import { Root } from '../Root';
import { TodoContext } from "../TodoContext";
import { TodoForm } from "../TodoForm";
import { TodosBorrados } from "../papelera/TodosBorrados";
import App from "../App";

function Initial({children}) {
    const {openModal,setOpenModal,initiaPage,setInitialPage,todopapelera,settodopapelera}=React.useContext(TodoContext)

        {initiaPage && <Root><App/></Root>}
    return(
        <div>
                {children}
        </div>
    )
}

export{Initial}