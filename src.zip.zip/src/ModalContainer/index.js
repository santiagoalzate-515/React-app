function ModalContainer({children}) {
    return(
        <span>
            {children}
        </span>
    )
}

export {ModalContainer};