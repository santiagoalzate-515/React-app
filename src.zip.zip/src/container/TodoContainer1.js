import React from "react";
import "./TodoContainer1.css"

function Todocontainer1({children}) {
    return(
      
            <div className="container-page">
            {children}
        </div>
      
        
    )
}

export{Todocontainer1}