function TodosLoading() {
    return(
        <p>Estamos Cargando...</p>
    )
}

export {TodosLoading}