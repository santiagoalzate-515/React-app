function Todocontainer({children}) {
    return(
        <span>
            {children}
        </span>
    )
}

export {Todocontainer};