function TodosError() {
    return(
        <p>Tenemos Un Error...</p>
    )
}

export {TodosError}