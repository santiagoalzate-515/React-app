import React from "react";
import { TodoContext } from "../TodoContext";
import "./TodoForm.css"

function TodoForm() {

    const {addTodo,openModal,setOpenModal}=React.useContext(TodoContext)
    const [newText,setNewText]=React.useState("")


    const onsubmit=()=>{
        setOpenModal(false)
        addTodo(newText)
    }

    const onchange=(text)=>{
        setNewText(text.target.value)
    }

    return(
        <div className="form-container">

            <form className="form" onSubmit={onsubmit}>
            <h2>ESCRIBE TU NOTA</h2>
            <textarea
            value={newText}
            onChange={onchange}
            ></textarea>
            <div className="container-button">
                <button >ENVIAR</button>
                <button >CANCELAR</button>
            </div>
            
            </form>
            </div>
    )
     
        
}

export{TodoForm}